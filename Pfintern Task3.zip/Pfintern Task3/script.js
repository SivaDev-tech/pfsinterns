document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('task-input');
    const addTaskButton = document.getElementById('add-task');
    const taskList = document.getElementById('task-list');
    const filterButtons = document.querySelectorAll('.filter-tasks button');
    
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

    // Add task
    addTaskButton.addEventListener('click', () => {
        const taskText = taskInput.value.trim();
        if (taskText !== '') {
            const newTask = { text: taskText, completed: false };
            tasks.push(newTask);
            localStorage.setItem('tasks', JSON.stringify(tasks));
            taskInput.value = '';
            renderTasks(tasks);
        }
    });

    // Toggle task completion
    taskList.addEventListener('click', (e) => {
        if (e.target.tagName === 'LI') {
            const index = e.target.dataset.index;
            tasks[index].completed = !tasks[index].completed;
            localStorage.setItem('tasks', JSON.stringify(tasks));
            renderTasks(tasks);
        } else if (e.target.classList.contains('delete')) {
            const index = e.target.parentElement.dataset.index;
            tasks.splice(index, 1);
            localStorage.setItem('tasks', JSON.stringify(tasks));
            renderTasks(tasks);
        } else if (e.target.classList.contains('edit')) {
            const index = e.target.parentElement.dataset.index;
            const newTaskText = prompt('Edit Task:', tasks[index].text);
            if (newTaskText !== null && newTaskText.trim() !== '') {
                tasks[index].text = newTaskText.trim();
                localStorage.setItem('tasks', JSON.stringify(tasks));
                renderTasks(tasks);
            }
        }
    });

    // Filter tasks
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            const filter = button.getAttribute('data-filter');
            let filteredTasks;
            if (filter === 'all') {
                filteredTasks = tasks;
            } else if (filter === 'completed') {
                filteredTasks = tasks.filter(task => task.completed);
            } else {
                filteredTasks = tasks.filter(task => !task.completed);
            }
            renderTasks(filteredTasks);
        });
    });

    // Render tasks
    function renderTasks(taskArray) {
        taskList.innerHTML = '';
        taskArray.forEach((task, index) => {
            const taskItem = document.createElement('li');
            taskItem.className = task.completed ? 'completed' : '';
            taskItem.dataset.index = index;
            taskItem.textContent = task.text;

            // Edit button
            const editButton = document.createElement('button');
            editButton.textContent = 'Edit';
            editButton.className = 'edit';
            taskItem.appendChild(editButton);

            // Delete button
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.className = 'delete';
            taskItem.appendChild(deleteButton);

            taskList.appendChild(taskItem);
        });
    }

    // Initial render
    renderTasks(tasks);
});
